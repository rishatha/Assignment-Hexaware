﻿using System;
using System.Collections.Generic;

namespace BankingSystemProject
{
    class TransactionHistory
    {
        public static void ManageTransactions()
        {
            List<string> transactions = new List<string>();

            while (true)
            {
                Console.WriteLine("Transaction Menu");
                Console.WriteLine("1. Deposit");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Exit and Show History");
                Console.Write("Choose an option: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 3)
                    break;

                Console.Write("Enter amount: ");
                double amount = Convert.ToDouble(Console.ReadLine());

                if (choice == 1)
                {
                    transactions.Add($"Deposit: {amount}");
                    Console.WriteLine("Deposit recorded.");
                }
                else if (choice == 2)
                {
                    transactions.Add($"Withdraw: {amount}");
                    Console.WriteLine("Withdrawal recorded.");
                }
                else
                {
                    Console.WriteLine("Invalid option.");
                }
            }

            Console.WriteLine("Transaction History");
            foreach (string txn in transactions)
            {
                Console.WriteLine(txn);
            }
        }
    }
}
