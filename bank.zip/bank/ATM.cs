﻿using System;

namespace BankingSystemProject
{
    class ATM
    {
        public static void ATMMenu()
        {
            double balance;
            Console.Write("Enter your current balance: ");
            balance = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("ATM Menu");
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Withdraw");
            Console.WriteLine("3. Deposit");
            Console.Write("Choose an option: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            if (choice == 1)
            {
                Console.WriteLine($"Your current balance is {balance}");
            }
            else if (choice == 2)
            {
                Console.Write("Enter amount to withdraw: ");
                double withdraw = Convert.ToDouble(Console.ReadLine());

                if (withdraw % 100 == 0 || withdraw % 500 == 0)
                {
                    if (withdraw <= balance)
                    {
                        balance -= withdraw;
                        Console.WriteLine($"Withdrawal successful. New balance: {balance}");
                    }
                    else
                    {
                        Console.WriteLine("Insufficient balance.");
                    }
                }
                else
                {
                    Console.WriteLine("Withdrawal amount must be in multiples of 100 or 500.");
                }
            }
            else if (choice == 3)
            {
                Console.Write("Enter amount to deposit: ");
                double deposit = Convert.ToDouble(Console.ReadLine());

                balance += deposit;
                Console.WriteLine($"Deposit successful. New balance: {balance}");
            }
            else
            {
                Console.WriteLine("Invalid option.");
            }
        }
    }
}
