﻿using System;

namespace BankingSystemProject
{
    class CompoundInterest
    {
        public static void CalculateInterest()
        {
            Console.Write("Enter number of customers: ");
            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= num; i++)
            {
                Console.WriteLine($"Customer {i}");

                Console.Write("Enter Initial Balance: ");
                double balance = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Annual Interest Rate (%): ");
                double rate = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Number of Years: ");
                int years = Convert.ToInt32(Console.ReadLine());

                double futureBalance = balance * Math.Pow(1 + rate / 100, years);

                Console.WriteLine($"Future Balance after {years} years: {futureBalance:F2}");
            }
        }
    }
}
