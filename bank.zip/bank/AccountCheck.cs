﻿using System;

namespace BankingSystemProject
{
    class AccountCheck
    {
        public static void CheckAccountBalance()
        {
            int[] accountNumbers = { 101, 102, 103, 104, 105 };
            double[] balances = { 1500, 500, 2000, 0, 1200 };

            while (true)
            {
                Console.Write("Enter Account Number to check balance (or 0 to exit): ");
                int acc = Convert.ToInt32(Console.ReadLine());

                if (acc == 0)
                    break;

                bool found = false;

                for (int i = 0; i < accountNumbers.Length; i++)
                {
                    if (acc == accountNumbers[i])
                    {
                        Console.WriteLine($"Account Found. Balance: {balances[i]}");
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    Console.WriteLine("Invalid Account Number. Please try again.");
                }
            }
        }
    }
}
