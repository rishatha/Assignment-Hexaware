﻿using System;

namespace BankingSystemProject
{
    class PasswordValidation
    {
        public static void ValidatePassword()
        {
            Console.Write("Create your password: ");
            string password = Console.ReadLine();

            bool isLongEnough = password.Length >= 8;
            bool hasUpper = false;
            bool hasDigit = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c))
                    hasUpper = true;
                if (char.IsDigit(c))
                    hasDigit = true;
            }

            if (isLongEnough && hasUpper && hasDigit)
            {
                Console.WriteLine("Password is valid.");
            }
            else
            {
                Console.WriteLine("Invalid Password. Requirements:");
                if (!isLongEnough) Console.WriteLine("- At least 8 characters.");
                if (!hasUpper) Console.WriteLine("- At least one uppercase letter.");
                if (!hasDigit) Console.WriteLine("- At least one digit.");
            }
        }
    }
}
