﻿using System;

namespace BankingSystemProject
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n=== Banking System Menu ===");
                Console.WriteLine("1. Loan Eligibility Check");
                Console.WriteLine("2. ATM Simulation");
                Console.WriteLine("3. Compound Interest Calculation");
                Console.WriteLine("4. Account Balance Check");
                Console.WriteLine("5. Password Validation");
                Console.WriteLine("6. Transaction History");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        LoanEligibility.CheckLoanEligibility();
                        break;
                    case 2:
                        ATM.ATMMenu();
                        break;
                    case 3:
                        CompoundInterest.CalculateInterest();
                        break;
                    case 4:
                        AccountCheck.CheckAccountBalance();
                        break;
                    case 5:
                        PasswordValidation.ValidatePassword();
                        break;
                    case 6:
                        TransactionHistory.ManageTransactions();
                        break;
                    case 7:
                        Console.WriteLine("Exiting the program.");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
    }
}
