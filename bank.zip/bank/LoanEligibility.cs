﻿using System;

namespace BankingSystemProject
{
    class LoanEligibility
    {
        public static void CheckLoanEligibility()
        {
            Console.WriteLine("Loan Eligibility Check");

            Console.Write("Enter Credit Score: ");
            int creditScore = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Annual Income: ");
            double income = Convert.ToDouble(Console.ReadLine());

            if (creditScore > 700 && income >= 50000)
            {
                Console.WriteLine("Eligible for loan.");
            }
            else
            {
                Console.WriteLine("Not eligible for loan.");
            }
        }
    }
}
