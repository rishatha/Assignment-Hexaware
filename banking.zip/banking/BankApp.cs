﻿using System;

namespace HMBankApp
{
    class BankApp
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();

            while (true)
            {
                Console.WriteLine("\n====== HMBank System ======");
                Console.WriteLine("1. Create Account");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Get Balance");
                Console.WriteLine("5. Transfer");
                Console.WriteLine("6. Get Account Details");
                Console.WriteLine("7. Exit");
                Console.Write("Choose option: ");
                string option = Console.ReadLine();

                try
                {
                    switch (option)
                    {
                        case "1":
                            Console.Write("Enter Customer ID: ");
                            int custId = int.Parse(Console.ReadLine());
                            Console.Write("Enter First Name: ");
                            string fname = Console.ReadLine();
                            Console.Write("Enter Last Name: ");
                            string lname = Console.ReadLine();
                            Console.Write("Enter Email: ");
                            string email = Console.ReadLine();
                            Console.Write("Enter Phone: ");
                            string phone = Console.ReadLine();
                            Console.Write("Enter Address: ");
                            string address = Console.ReadLine();
                            Console.Write("Enter Account Type (Savings/Current): ");
                            string accType = Console.ReadLine();
                            Console.Write("Enter Initial Balance: ");
                            decimal balance = decimal.Parse(Console.ReadLine());

                            var customer = new Customer(custId, fname, lname, email, phone, address);
                            bank.CreateAccount(customer, accType, balance);
                            break;

                        case "2":
                            Console.Write("Enter Account No: ");
                            long accNo = long.Parse(Console.ReadLine());
                            Console.Write("Enter Amount to Deposit: ");
                            decimal depositAmount = decimal.Parse(Console.ReadLine());
                            decimal newBal = bank.Deposit(accNo, depositAmount);
                            Console.WriteLine($"Deposited. New Balance: ₹{newBal}");
                            break;

                        case "3":
                            Console.Write("Enter Account No: ");
                            long accNoW = long.Parse(Console.ReadLine());
                            Console.Write("Enter Amount to Withdraw: ");
                            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
                            decimal balAfterWithdraw = bank.Withdraw(accNoW, withdrawAmount);
                            Console.WriteLine($"Balance After Withdrawal: ₹{balAfterWithdraw}");
                            break;

                        case "4":
                            Console.Write("Enter Account No: ");
                            long accBal = long.Parse(Console.ReadLine());
                            Console.WriteLine($"Balance: ₹{bank.GetAccountBalance(accBal)}");
                            break;

                        case "5":
                            Console.Write("From Account No: ");
                            long fromAcc = long.Parse(Console.ReadLine());
                            Console.Write("To Account No: ");
                            long toAcc = long.Parse(Console.ReadLine());
                            Console.Write("Enter Amount to Transfer: ");
                            decimal transferAmount = decimal.Parse(Console.ReadLine());
                            bank.Transfer(fromAcc, toAcc, transferAmount);
                            break;

                        case "6":
                            Console.Write("Enter Account No: ");
                            long accDetails = long.Parse(Console.ReadLine());
                            bank.GetAccountDetails(accDetails);
                            break;

                        case "7":
                            Console.WriteLine("Exiting...");
                            return;

                        default:
                            Console.WriteLine("Invalid option. Try again.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }
    }
}
