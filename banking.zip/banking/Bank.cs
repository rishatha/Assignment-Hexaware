﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;

namespace HMBankApp
{
    public class Bank
    {
        private List<Account> accounts = new List<Account>();
        private long nextAccountNumber = 1001;

        public Account CreateAccount(Customer customer, string accType, decimal balance)
        {
            var account = new Account(nextAccountNumber++, accType, balance, customer);
            accounts.Add(account);
            Console.WriteLine($"Account created successfully. Account Number: {account.AccountNumber}");
            return account;
        }

        public decimal GetAccountBalance(long accNo)
        {
            var acc = FindAccount(accNo);
            return acc?.Balance ?? throw new Exception("Account not found.");
        }

        public decimal Deposit(long accNo, decimal amount)
        {
            var acc = FindAccount(accNo);
            acc.Balance += amount;
            return acc.Balance;
        }

        public decimal Withdraw(long accNo, decimal amount)
        {
            var acc = FindAccount(accNo);
            if (acc.Balance >= amount)
            {
                acc.Balance -= amount;
            }
            else
            {
                Console.WriteLine("Insufficient balance.");
            }
            return acc.Balance;
        }

        public void Transfer(long fromAccNo, long toAccNo, decimal amount)
        {
            var fromAcc = FindAccount(fromAccNo);
            var toAcc = FindAccount(toAccNo);
            if (fromAcc.Balance >= amount)
            {
                fromAcc.Balance -= amount;
                toAcc.Balance += amount;
                Console.WriteLine("Transfer successful.");
            }
            else
            {
                Console.WriteLine("Transfer failed: Insufficient funds.");
            }
        }

        public void GetAccountDetails(long accNo)
        {
            var acc = FindAccount(accNo);
            acc?.PrintDetails();
        }

        private Account FindAccount(long accNo)
        {
            return accounts.FirstOrDefault(a => a.AccountNumber == accNo);
        }
    }
}
