﻿using System;
using System.Text.RegularExpressions;

namespace HMBankApp
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        private string email;
        public string Email
        {
            get => email;
            set
            {
                if (Regex.IsMatch(value, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    email = value;
                else
                    throw new ArgumentException("Invalid email format.");
            }
        }

        private string phoneNumber;
        public string PhoneNumber
        {
            get => phoneNumber;
            set
            {
                if (Regex.IsMatch(value, @"^\d{10}$"))
                    phoneNumber = value;
                else
                    throw new ArgumentException("Phone number must be 10 digits.");
            }
        }

        public string Address { get; set; }

        public Customer() { }

        public Customer(int customerId, string firstName, string lastName, string email, string phoneNumber, string address)
        {
            CustomerId = customerId;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            PhoneNumber = phoneNumber;
            Address = address;
        }

        public void PrintDetails()
        {
            Console.WriteLine($"Customer ID: {CustomerId}, Name: {FirstName} {LastName}, Email: {Email}, Phone: {PhoneNumber}, Address: {Address}");
        }
    }
}
