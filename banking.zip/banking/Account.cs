﻿using System;

namespace HMBankApp
{
    public class Account
    {
        public long AccountNumber { get; set; }
        public string AccountType { get; set; }
        public decimal Balance { get; set; }
        public Customer Customer { get; set; }

        public Account() { }

        public Account(long accountNumber, string accountType, decimal balance, Customer customer)
        {
            AccountNumber = accountNumber;
            AccountType = accountType;
            Balance = balance;
            Customer = customer;
        }

        public void PrintDetails()
        {
            Console.WriteLine($"\nAccount No: {AccountNumber}, Type: {AccountType}, Balance: ₹{Balance}");
            Customer.PrintDetails();
        }
    }
}
